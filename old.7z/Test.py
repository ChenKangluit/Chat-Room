from cryptography.fernet import Fernet

# 生成一个密钥并创建一个加密套件对象
key = Fernet.generate_key()
cipher_suite = Fernet(key)

# 加密信息
message = "tom: hello"
encrypted_message = cipher_suite.encrypt(message.encode('utf-8'))
print(f"Encrypted message: {encrypted_message}")

# 解密信息
decrypted_message = cipher_suite.decrypt(encrypted_message).decode('utf-8')
print(f"Decrypted message: {decrypted_message}")
